<section id="city">
    <div class="city-box city-box__container">


        <div class="city-box__element">
            <div class="city-box__title">
                <p class="city-box__title city-box__title--small">Mniejszy tekst</p>
                <h1 class="city-box__title city-box__title--big">Przykładowy nagłówek.</h1>
            </div>
            <img class="city-box__image" src="<?php bloginfo('template_url'); ?>/assets/img/sample.jpg" />

        </div>

        <div class="city-box__element">


            <p class="city-box__text">
                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the
                industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and
                scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap
                into electronic typesetting, remaining essentially unchanged.
            </p>

            <div class="city-box__cities">
                <div class="city-box__city">Warszawa</div>
                <div class="city-box__city">Kraków</div>
                <div class="city-box__city">Częstochowa</div>
                <div class="city-box__city">Opole</div>
            </div>
        </div>

    </div>
</section>