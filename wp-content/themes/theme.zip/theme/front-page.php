<?php
/* Template Name: Home */
?>

<?php get_header(); ?>
<main id="home">
    <?php the_content()?>


</main>
<?php
get_footer();