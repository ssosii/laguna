<?php
/* REGISTER CATEGORY*/
// function example_block_category($categories, $post){
//     return array_merge(
//         $categories,
//         array(
//             array(
//                 'slug' => 'category',
//                 'title' => 'Category'
//             ),
//         ),
        
//     );
// }
// function dotlinecode_acf_blocks_register(){
//     if (function_exists('acf_register_block_type')) {
//         acf_register_block_type(array(
//             'name'              => 'name',
//             'title'             => __('title'),
//             'render_template'   => '//path.php',
//             'category'          => 'category',
//             'icon'              => 'schedule',
//             'keywords'          => array('keywords'),
//             'mode'    => 'edit',
//         ));
//     }
// }
// add_action('acf/init', 'dotlinecode_acf_blocks_register');