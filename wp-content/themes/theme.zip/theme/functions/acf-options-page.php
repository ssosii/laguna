<?php
// ACF Theme setting page

// function my_acf_op_init()
// {
//     // Footer tabs
//     acf_add_options_page(array(
//         'page_title'     => 'Stopki',
//         'menu_title'    => 'Stopki',
//         'menu_slug'     => 'footer-all',
//     ));
// };
// add_action('acf/init', 'my_acf_op_init');