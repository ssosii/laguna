<section id="map-contact">
    <div class="map-contact map__container">

        <div class="map-contact__box">
            <iframe src="<?php the_field("link")?>" width="600" height="450" style="border:0;" allowfullscreen=""
                loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
        <div class="map-contact__box">
            <div class="map-contact__data">
                <?php the_field("dane_kontaktowe")?>

            </div>
        </div>

    </div>
</section>