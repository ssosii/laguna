<section id="process">
    <h2 class="main--title --center">Proces</h2>
    <div class="container">
        <div class="process--list">
            <div class="item">
                <div class="image">
                    <img src="<?php bloginfo('template_url'); ?>/assets/img/sample.jpg" />
                </div>
                <h3 class="title">Sed ut perspiciatis unde omnis iste natus error sit voluptatem</h3>
                <p class="description">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu
                    fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia
                    deserunt mollit anim id est laborum.</p>
            </div>
            <div class="item">
                <div class="image">
                    <img src="<?php bloginfo('template_url'); ?>/assets/img/sample.jpg" />
                </div>
                <h3 class="title">Sed ut perspiciatis unde omnis iste natus error sit voluptatem</h3>
                <p class="description">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu
                    fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia
                    deserunt mollit anim id est laborum.</p>
            </div>
            <div class="item">
                <div class="image">
                    <img src="<?php bloginfo('template_url'); ?>/assets/img/sample.jpg" />
                </div>
                <h3 class="title">Sed ut perspiciatis unde omnis iste natus error sit voluptatem</h3>
                <p class="description">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu
                    fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia
                    deserunt mollit anim id est laborum.</p>
            </div>
            <div class="item">
                <div class="image">
                    <img src="<?php bloginfo('template_url'); ?>/assets/img/sample.jpg" />
                </div>
                <h3 class="title">Sed ut perspiciatis unde omnis iste natus error sit voluptatem</h3>
                <p class="description">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu
                    fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia
                    deserunt mollit anim id est laborum.</p>
            </div>

        </div>


</section>