<section id="single-box">
    <div class="single-box single-box__container">

        <div class="single-box__element">

            <div class="single-box__title">
                <p class="single-box__title single-box__title--small">Mniejszy tekst</p>
                <h1 class="single-box__title single-box__title--big">Przykładowy nagłówek.</h1>
            </div>
            <p class="single-box__text">
                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the
                industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and
                scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap
                into electronic typesetting, remaining essentially unchanged.
            </p>
        </div>
        <div class="single-box__element">

            <img class="single-box__image" src="<?php bloginfo('template_url'); ?>/assets/img/sample.jpg" />

        </div>

    </div>

    <div class="single-box single-box__container">

        <div class="single-box__element">

            <div class="single-box__title">
                <p class="single-box__title single-box__title--small">Mniejszy tekst</p>
                <h1 class="single-box__title single-box__title--big">Przykładowy nagłówek.</h1>
            </div>
            <p class="single-box__text">
                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the
                industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and
                scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap
                into electronic typesetting, remaining essentially unchanged.
            </p>
        </div>
        <div class="single-box__element">

            <img class="single-box__image" src="<?php bloginfo('template_url'); ?>/assets/img/sample.jpg" />

        </div>

    </div>
</section>